line = input("Enter a line of values seperated by a comma:")

lineitems = line.split(",")
for item in lineitems:
  print(item.strip())
  