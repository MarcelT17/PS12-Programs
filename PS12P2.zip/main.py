def getinput():
  txt = input("Enter line of text:")
  return txt

def removeduplicate(txt):
  txt2 = txt.strip()
  txt3 = re.sub('+','',txt2)
  txt4 = txt3[::-1]
  return txt4

def printText(txt):
  print(txt)
  printText(updatedText)
  