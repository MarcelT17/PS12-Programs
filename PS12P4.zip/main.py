scrolldirection = input("Enter the scroll direction: (r) or (l)")

if scrolldirection == "r":
  shift = ""
elif scrolldirection == "l":
  shift = " " * (line - 1)

for i in range(line):
  print(shift, end='')
if scrolldirection == "r":
  shift = "  "
elif scrolldirection == "l":
  shift = ""
line = input("Enter a line of text: ")
